// If you need a separate db.ts file, you can import the connection from dbConnection.ts
const db = require('./dbConnection');

// Your additional db-related code, if any

module.exports = db;

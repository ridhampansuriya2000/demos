const express = require('express');
const bodyParser = require('body-parser');
const taskRoutes = require('./routes/taskRoutes');
require('nodemon');
const db = require('./dbConnection');

const app = express();

app.use(bodyParser.json());
app.use('/api', taskRoutes);

const PORT = require('./config').port;

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

db.on('connected', () => {
    console.log('Connected to MongoDB');
});

db.on('error', (err: any) => {
    console.error('MongoDB connection error:', err);
});

let express = require("express");
let app = express();
let ejs = require("ejs");
const puppeteer = require('puppeteer');
const path = require("path");

app.use(express.static(path.join(__dirname, "public")));

// Define your chart data
const chartData1 = {
	labels: ['2012', '2013', '2014', '2015', '2016', '2017'],
	label: 'No of Votes',
	data: [12, 19, 3, 5, 2, 3]
};

const chartData = {
	labels: ['2012', '2013', '2014', '2015', '2016', '2017', '2018'],
	datasets: [{
		label: 'No of Votes',
		data: [65, 59, 80, 81, 56, 55, 40],
		fill: false,
		borderColor: 'rgb(75, 192, 192)',
		tension: 0.1
	}]
};

app.get("/generateReport", async (req, res) => {
	const browser = await puppeteer.launch({
		headless: 'false',
	});
	const page = await browser.newPage();
	const html = await ejs.renderFile('views/report-template.ejs', chartData);
	await page.setContent(html, {waitUntil: 'domcontentloaded'});

	const pdfBuffer = await page.pdf({format: 'A4'});

	res.setHeader("Content-Disposition", "attachment; filename=report.pdf");
	res.setHeader("Content-Type", "application/pdf");
	res.send(pdfBuffer);
});

app.get("/test", (req, res) => {
	res.render("report-template.ejs",chartData);
});

app.listen(5000, () => {
	console.log('Server Is running At 5000');
});
